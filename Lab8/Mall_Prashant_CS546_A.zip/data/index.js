const tvMazeApiData = require("./tvMazeApi");

module.exports = {
  tvMazeApi: tvMazeApiData,
};
